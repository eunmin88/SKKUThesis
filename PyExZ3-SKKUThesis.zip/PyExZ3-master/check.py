import sys
import os
import filecmp
qnum = ["question_1", "question_2", "question_3", "question_4", "question_5"]
qnum2 = ["question_1_EC", "question_2_EC", "question_3_EC", "question_4_EC", "question_5_EC"]
max = 596
count = 1
exists = 0
fail = []
check = False
while(count < max):
	num = '0'
	if count < 10:
		num = '00'
	elif count > 9 and count < 100:
		num = '0'
	else:
		num = ''
	num = num + str(count)
	one = qnum[2]+'/reference.txt'
	two = qnum[2]+'/correct_3_'+num+'.txt'
	try:
		f = open(two)
		exists = 1
	except IOError:
		check = False

	finally:
		f.close()
	if exists == 1:
		check = filecmp.cmp(one, two, shallow=False)
	if check == False:
		fail.append(num)
	count = count + 1
	exists = 0
	check = False
f = open("true_correct_3.txt", "w")
for fa in fail:
	f.write(str(fa))
	f.write("\n")
f.close()
	
