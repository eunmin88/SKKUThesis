import glob, os
with open('true_correct_3.txt', 'r') as f:
	lines = f.readlines()
	for line in lines:
		for file in os.listdir("/home/eunmin/Desktop/PyExZ3-master/3_new"):
			line = line.strip('\n')
			if line in str(file):
				os.remove("/home/eunmin/Desktop/PyExZ3-master/3_new/" + file)
		
		
