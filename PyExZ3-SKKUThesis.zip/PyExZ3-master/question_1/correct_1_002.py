seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    """ Takes in a value x and a sorted sequence seq, and returns the
    position that x should go to such that the sequence remains sorted """
    output = 0
    while output < len(seq):
        if x > seq[output]:
            output += 1
        else:
            break
    return output

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]