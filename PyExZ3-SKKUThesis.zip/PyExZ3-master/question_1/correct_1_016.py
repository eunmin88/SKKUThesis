seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if seq==() or seq==[]:
        return 0
    for a,b in enumerate(seq):
        if x<=b:
            return a
    for i in seq:
        if x>i:
            return a+1

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]