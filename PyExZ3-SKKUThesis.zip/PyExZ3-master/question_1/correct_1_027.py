seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    """ Takes in a value x and a sorted sequence seq, and returns the
    position that x should go to such that the sequence remains sorted """
    for i,ele in enumerate(seq):
        if x<=ele:    #if x is less/equal to the specific element in the list
            return i   #return the index to be inserted in
    return len(seq)

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]