seq = (-5, 1, 3, 5, 7, 10)
def search(x):
	seq=list(seq)
	if seq==[]:
		return 0
	else:
		for i in seq:
			if x<=i:
				num=seq.index(i)
				break
			else:
				num=len(seq)
	return num

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]