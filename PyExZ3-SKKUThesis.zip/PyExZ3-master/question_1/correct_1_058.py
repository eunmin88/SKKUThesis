seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    lst = list(seq)
    if lst == []:
        lst.append(x)
    else:
        for i in range(len(lst)):
            if x < lst[i]:
                lst.insert(i,x)
            else:
                lst.insert(len(lst),x)
    for i in range(len(lst)):
         if lst[i] == x:
             return i

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]