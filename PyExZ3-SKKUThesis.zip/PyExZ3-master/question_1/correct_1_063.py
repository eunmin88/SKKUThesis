seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    length = len(seq)
    if length == 0: return 0
    elif length == 1: return 0 if x < seq[0] else 1
    else:
        for i in range(length):
            if x <= seq[i]: return i
        return length # x is larger than everything in seq, so x goes to the end

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]