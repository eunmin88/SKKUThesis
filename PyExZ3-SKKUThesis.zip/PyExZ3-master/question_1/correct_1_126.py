seq = (-5, 1, 3, 5, 7, 10)
def search(x):

    count = 0

    for i in seq:
        if x > i:
            count += 1 
    return count
    
    
    """ Takes in a value x and a sorted sequence seq, and returns the
    position that x should go to such that the sequence remains sorted """
    return

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]