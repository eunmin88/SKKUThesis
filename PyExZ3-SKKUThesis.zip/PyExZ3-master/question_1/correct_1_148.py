seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    index = []
    for i, elem in enumerate(seq):
        index += [[i, elem],]
    for i in index:
        if x <= i[1]:
            return i[0]
    else: return len(seq)

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]