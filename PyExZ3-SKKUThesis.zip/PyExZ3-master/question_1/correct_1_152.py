seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    result = 0
    counter = 0
    while counter < len(seq):
        temp = seq[counter]
        if x <= temp:
            return counter
        counter = counter + 1
    if counter == 0 and len(seq)!= 0:
        return len(seq)
    return counter

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]