seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if seq == () or seq == []:
        return 0
    for i in range (0, len(seq)):
        if x <= seq[i]:
           pos = i
           return pos
        if x > seq[len(seq)-1]:
           return len(seq)
        

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]