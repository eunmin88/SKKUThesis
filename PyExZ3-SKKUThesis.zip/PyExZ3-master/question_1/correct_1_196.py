seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    position=enumerate(seq)
    if len(seq)==0:
        return 0
    elif x>seq[-1]:
        return len(seq)
    else: 
        for i in seq:
            if x<=i:
                for index in position:
                    if index[1]==i:
                        return index[0]

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]