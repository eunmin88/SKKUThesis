seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    a = 0
    for i,j in enumerate(seq):
        if x > j and i < len(seq)-1:
            continue
        elif x <= j:
            a = i
            break
        else:
            a = len(seq)
    return a

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]