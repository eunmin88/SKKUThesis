seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if len(seq) == 0:
        return 0
    elif x > seq[len(seq)-1]:
        return len(seq)
    elif x < seq[0]:
        return 0
    else:
        for i in seq:
            if x > i:
                continue
            else:
                return seq.index(i) 

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]