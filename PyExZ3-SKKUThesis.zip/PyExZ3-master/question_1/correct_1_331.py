seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if seq == ():
        return 0
    elif seq == []:
        return 0
    else:
        for i,elem in enumerate(seq):
            if x < seq[-1]:
                if x > elem:
                    continue
                elif x < elem and type(seq) == tuple:
                    seq = seq[:i] + (x,) + seq[i:]
                elif x < elem and type(seq) == list:
                    seq = seq[:i] + [x,] + seq[i:]
            elif x > seq[-1]:
                if type(seq) == tuple:
                    seq += (x,)
                elif type(seq) == list:
                    seq += [x,]
        return seq.index(x)

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]