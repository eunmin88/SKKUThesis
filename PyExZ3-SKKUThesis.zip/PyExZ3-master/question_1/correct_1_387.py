seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if seq == [] or seq == ():
        return  0
    if x <= seq[0]:
        position = 0
    if x >= seq[len(seq) - 1]:
        position = len(seq)
    for i in range(len(seq)):
        if x <= seq[i] and x > seq[i-1]:
            position = i
    return position


def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]