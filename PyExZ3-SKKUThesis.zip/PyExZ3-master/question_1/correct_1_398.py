seq = (-5, 1, 3, 5, 7, 10)
#def search(x):
 #   if len(seq)==0:
  #      return 0
   # for i in range(len(seq)):
    #    if x<= seq[i]:
     #       a=i
      #      break
       # elif x> seq[len(seq)-1]:
        #    a=len(seq)
    #return a

#def search(x):
 #   if len(seq)==0:
  #      a=0
   # elif x>seq[len(seq)-1]:
    #    a= len(seq)
#    else:
 #       for i,elem in enumerate(seq):
  #          if  x <=elem:
   #             a=i
    #            break
    #return a
def search(x):
    for i,elem in enumerate(seq):
            if  x <=elem:
                a=i
                break
    if len(seq)==0:
        a=0
    elif x>seq[len(seq)-1]:
        a= len(seq)
    return a
 

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]