seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    """ Takes in a value x and a sorted sequence seq, and returns the
    position that x should go to such that the sequence remains sorted """
    enumerated_list =()
    res= 0
    for i, elem in enumerate(seq):
        enumerated_list = enumerated_list + ((i,elem),)

    for number in enumerated_list:
        if x <= number[1]:
            res = number[0]
            break
        else:
            res = len(seq)
    return res

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]