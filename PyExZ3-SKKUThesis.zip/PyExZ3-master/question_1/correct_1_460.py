seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    for i in range(0, len(seq) + 1):
        if len(seq) == 0:
            return 0
        elif x < seq[0]:
            return 0
        elif seq[i] < x <= seq[i+1]:
            return i + 1
        elif seq[len(seq)-1] < x:
            return len(seq)

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]