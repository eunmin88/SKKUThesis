seq = (-5, 1, 3, 5, 7, 10)
def search(key, seq):
    lst = list(seq)
    n = len(lst)
    for i in range(n+1): #0,1,2,3 
        if i <= n-1 and key <= lst[i]:
            return i
    return n 

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]