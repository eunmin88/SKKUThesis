seq = (-5, 1, 3, 5, 7, 10)
def search(x,seq):
    counter = 0
    for i in seq:
        if i < x:
            counter = counter + 1
    return counter

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]