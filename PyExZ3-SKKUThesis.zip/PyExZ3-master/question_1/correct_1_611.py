seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    result=0
    for i in range(len(seq)):
        if seq[i]<x:
            result+=1
    return result

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]