seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    counter = 0
    for i in range(len(seq)):
        if x <= seq[i]:
            break
        else:
            counter += 1
    return counter

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]