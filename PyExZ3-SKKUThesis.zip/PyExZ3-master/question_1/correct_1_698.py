seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if seq == []:
        return 0
    for elem in seq:
        if x < elem:
            return seq.index(elem)
        elif x == elem:
            return seq.index(elem)
    return len(seq)

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]