seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    list2 = list(enumerate(seq))
    if list2 == []: 
        return 0
    else:
        for i in list2:
            if x <= (i[1]):
                return i[0] 
        return len(seq) 

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]