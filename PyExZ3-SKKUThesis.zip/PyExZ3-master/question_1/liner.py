import os
path = os.getcwd()

count = 1

while count < 835:
	num = '0'
	if count < 10:
		num = '00'
	elif count > 9 and count < 100:
		num = '0'
	else:
		num = ''
	num = num + str(count)
	temp = path + "/correct_1_"+num+".py"
	with open(temp) as f:
		t = f.read().replace("search(x, seq)", "search(x)")
	with open(temp, "w") as f:
		f.write(t)
	with open(temp, 'r') as original: data = original.read()
	with open(temp, 'w') as modified: modified.write("seq = (-5, 1, 3, 5, 7, 10)\n" + data + "\n" + "def expected_result():\n" + "\treturn [5, 6, 4, 3, 2, 0, 1]")

	count += 1

