import os
qnum = ["question_1", "question_2", "question_3", "question_4", "question_5"]
qnum2 = ["question_1_EC", "question_2_EC", "question_3_EC", "question_4_EC", "question_5_EC"]
name = ["search", "contains_unique_day", "remove_extras", "sort_age", "top_k"]
count = 1
os.system("python3 pyexz3.py --start=" + name[2] +" " + qnum[2]+"/reference.py")

while count < 596:
	num = '0'
	if count < 10:
		num = '00'
	elif count > 9 and count < 100:
		num = '0'
	else:
		num = ''
	num = num + str(count)
	print(num)
	os.system("python3 pyexz3.py --start=" + name[2] + " --max-iters=7 "+qnum[2]+"/correct_3_"+num+".py")
	count = count + 1


