seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    y = len(seq)
    if y == 0 or x < seq[0]:
        return 0
    else:
        for i in range(y-1):
            if x > seq[i] and x <= seq[i+1]:
                return i + 1
        return y
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]