seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    i=0
    while i<len(seq):
        if x<=seq[i]:
            break
        i=i+1 
    return i
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]