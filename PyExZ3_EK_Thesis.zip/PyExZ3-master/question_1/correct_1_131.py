seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    for i, y in enumerate(seq):
        if x <= y:
            return i
    if seq == [] or seq == (): 
        return 0
    else:
        return 1+i
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]