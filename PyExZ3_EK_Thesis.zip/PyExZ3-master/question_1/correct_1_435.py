seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    counter = 0
    new_seq = list(seq)
    if new_seq == []:
        return 0
    for element in seq:
        if x <=element:
            return counter
        if x > seq[len(seq)-1]:
            return len(seq) 
        else:
            counter += 1
            continue
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]