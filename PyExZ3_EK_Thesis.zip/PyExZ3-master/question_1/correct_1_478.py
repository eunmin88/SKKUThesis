seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    n = len(seq)
    for i in range(n):
        next_element = seq[i]
        if x <= next_element:
            return i
    return n
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]