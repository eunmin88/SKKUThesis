seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    for i in range(len(seq)):
        if x<=seq[i]:
            return i
            break
        else:
            continue
        
    return len(seq)
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]