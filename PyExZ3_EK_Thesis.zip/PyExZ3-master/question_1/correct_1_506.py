seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    index = 0
    while index < len(seq):
        if x <= seq[index]:
            break
        else:
            index += 1
    return index
    
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]