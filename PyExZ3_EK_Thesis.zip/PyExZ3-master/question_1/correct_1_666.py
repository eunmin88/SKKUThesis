seq = (-5, 1, 3, 5, 7, 10)
def search(x):
	counter = 0
	for i in seq:
		counter += 1
		if x <= i:
			return counter-1
	return len(seq)
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]