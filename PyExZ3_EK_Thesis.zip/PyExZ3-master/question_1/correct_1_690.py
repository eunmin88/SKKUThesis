seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if seq == []:
        return 0
    else:
        for i in range(len(seq)):
            if x <= seq[i]:
                return i
        return len(seq) 
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]