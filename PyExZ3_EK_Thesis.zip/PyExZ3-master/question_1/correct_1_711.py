seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    """ Takes in a value x and a sorted sequence seq, and returns the
    position that x should go to such that the sequence remains sorted """
    lst = list(seq)
    lst.append(x)
    lst.sort()
    tup = tuple(enumerate(lst))
    for i in range(len(tup)):
        if tup[i][1]==x:
            return tup[i][0]
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]