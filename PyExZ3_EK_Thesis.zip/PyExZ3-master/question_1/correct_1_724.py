seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if not seq:
        return 0
    else:
        if x < seq[0]:
            indx = 0
        elif x > seq[-1]:
            indx = seq.index(seq[-1]) + 1
        else:
            for i in seq:
                if x <= i:
                    indx = (seq.index(i))
                    break                    
        return indx
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]