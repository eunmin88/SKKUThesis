seq = (-5, 1, 3, 5, 7, 10)
def search(x):

    new_lst = []

    if len(seq) == 0:

        return 0

    for i, elem in enumerate(seq):

        new_lst.append((i, elem))

    for i in new_lst:

        if x <= i[1]:

            return i[0]

        else:

            continue

    return len(seq)
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]