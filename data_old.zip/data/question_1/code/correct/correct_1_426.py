def search(x, seq):
    t = 0
    for i in seq:
        if x > i:
            t+=1

    return t
    
    
    
