seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    n=[]
    seq = list(seq)
    a= seq.copy()
    d = 0        
    if seq == []:
        return 0
    for i in a:
        if i<x:
            n.append(i)
            seq.remove(i)
        elif i == x:
            n.append(i)
            n.append(x)
            n.extend(seq)
            break
        else:
            n.append(x)
            n.extend(seq)
            break
    count = list(enumerate(n))
    for b in count:
        d+=1
        if b[1] == x:
            return b[0]
        elif d==len(count):
            return d
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]