seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if len(seq)==0:
        return 0
    a = list(enumerate(seq))
    for item in a:
        if x <= item[1]:
            return item[0]
    if x > seq[-1]:
        return len(seq)
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]