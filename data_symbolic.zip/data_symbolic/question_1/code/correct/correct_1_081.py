seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    for i, elem in enumerate(seq):
        if x <= elem:
            return i
    return len(seq)
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]