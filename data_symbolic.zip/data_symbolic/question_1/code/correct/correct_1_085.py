seq = (-5, 1, 3, 5, 7, 10)

def search(x):
    new_seq=list(seq)
    new_seq.append(x)
    sort=[]
    while new_seq:
        smallest=new_seq[0]
        for element in new_seq:
            if element<smallest:
                smallest=element
        new_seq.remove(smallest)
        sort.append(smallest)
    for i,elem in enumerate(sort):
        if elem==x:
            return i
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]