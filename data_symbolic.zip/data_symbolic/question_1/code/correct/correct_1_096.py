seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if type(seq) == list:
        a = seq.copy()
        a.append(x)
        a.sort()
        for i, elem in enumerate(a):
            if elem == x:
                return i
    else:
        temp_list = list(seq)
        temp_list.append(x,)
        temp_list.sort()
        for i, elem in enumerate(temp_list):
            if elem == x:
                return i
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]