seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    seq_len = len(seq)
    for i in range(seq_len):
        if x <= seq[i]: return i
    return seq_len
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]