seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    """ Takes in a value x and a sorted sequence seq, and returns the
    position that x should go to such that the sequence remains sorted """
    counter = 0
    result = 0
    while counter < len(seq):
        if x < min(seq):
            result = 0
            break
        elif x > max(seq):
            result = len(seq)
            break
        elif x <= seq[counter]:
            result = counter
            break
        counter += 1
    return result
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]