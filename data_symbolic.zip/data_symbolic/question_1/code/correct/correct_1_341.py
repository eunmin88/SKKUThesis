seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    index = 0
    def helper(index):
        if not seq:
            return 0
        elif x <= seq[index]:
            return index
        else:
            if index + 1 >= len(seq):
                return index + 1
            else:
                return helper(index+1)
    return helper(index)
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]