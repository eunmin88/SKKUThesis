seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if type(seq) == list:
        seq.append(x)
        seq.sort()
        for i, elem in enumerate(seq):
            if elem == x:
                return i
    else:
        seq+=(x,)
        for i, elem in enumerate(sorted(seq)):
            if elem == x:
                return i
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]