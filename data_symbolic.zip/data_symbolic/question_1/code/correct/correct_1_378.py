seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    for i in enumerate(seq):
        if x <= i[1]:
            if i[0] == 0:
                return 0
            else:
                return i[0]
    return len(seq)
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]