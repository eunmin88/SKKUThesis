seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    lenth=len(seq)
    for i in range(0,lenth):
        if x>seq[i]:
            continue
        else:
            return i
    return lenth

def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]