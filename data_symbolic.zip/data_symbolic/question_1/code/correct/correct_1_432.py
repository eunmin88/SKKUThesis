seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    if seq == () or seq == []:
        return 0
    if seq[0] >= x:
        return 0
    elif seq[len(seq)-1] < x:
        return len(seq)
    else:
        for i in range(len(seq)-1):
            if seq[i] < x and seq[i+1] >= x:
                return i+1
                break
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]