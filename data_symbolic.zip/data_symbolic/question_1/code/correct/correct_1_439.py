seq = (-5, 1, 3, 5, 7, 10)
def search(x):
    position = 0
    while position < len(seq):
        if seq[position] == x:
             break
        elif seq[position] > x:
            break
        position = position + 1
    return position
def expected_result():
	return [5, 6, 4, 3, 2, 0, 1]