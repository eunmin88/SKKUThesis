#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2022 Pynguin Contributors
#
#  SPDX-License-Identifier: LGPL-3.0-or-later
#


def first(a: int) -> int:
    if a > 0:
        return 42
    return 0


def second(b: int) -> int:
    if b > 0:
        return 0
    return 42
