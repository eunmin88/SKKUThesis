#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2022 Pynguin Contributors
#
#  SPDX-License-Identifier: LGPL-3.0-or-later
#
# Dummy method for testing adding a value
def compare_op_dummy(x, y):
    if x == y:
        return 0
    else:
        return 1
